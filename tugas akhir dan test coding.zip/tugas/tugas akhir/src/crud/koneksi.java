/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;
import inputan.*;
import tugaspertanian.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author User
 */
public class koneksi {
    private String databasename="pertanian";
    private String username="root";
    private String password="";
    private String lokasi="jdbc:mysql://localhost/"+databasename;
    public static Connection koneksidb; 
    
    public koneksi(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            koneksidb=DriverManager.getConnection(lokasi,username,password);
            System.out.println("Databse Terkoneksi");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    
    public void simpanadmin(String varadmin, String varuser, String varpass, String varnama) {
        try {
            String kode = "INSERT INTO admin (id_admin, username, password, nama_lengkap) VALUES (?, ?, ?, ?)";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, varadmin);
            perintah.setString(2, varuser);
            perintah.setString(3, varpass);
            perintah.setString(4, varnama);
            perintah.executeUpdate();
            System.out.println("Data berhasil disimpan");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void ubahadmin(String varadmin, String varuser, String varpass, String varnama) {
        try {
            String kode = "UPDATE admin SET username = ?, password = ?, nama_lengkap = ? WHERE id_admin = ?";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, varuser);
            perintah.setString(2, varpass);
            perintah.setString(3, varnama);
            perintah.setString(4, varadmin);
            perintah.executeUpdate();
            System.out.println("Data berhasil diubah");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void hapusadmin(String varadmin) {
        try {
            String kode = "DELETE FROM admin WHERE id_admin = ?";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, varadmin);
            perintah.executeUpdate();
            System.out.println("Data berhasil dihapus");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    
    public void simpantanaman(String id, String luasPanen, String produksi, String idLokasi, String idJenisTanaman, String tahun) {
        try {
            String kode = "INSERT INTO data_tanaman (id, luas_panen, produksi, id_lokasi, id_jenis_tanaman, tahun) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, id);
            perintah.setString(2, luasPanen);
            perintah.setString(3, produksi);
            perintah.setString(4, idLokasi);
            perintah.setString(5, idJenisTanaman);
            perintah.setString(6, tahun);
            perintah.executeUpdate();
            System.out.println("Data berhasil disimpan");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void ubahtanaman(String id, String luasPanen, String produksi, String idLokasi, String idJenisTanaman, String tahun) {
        try {
            String kode = "UPDATE data_tanaman SET luas_panen = ?, produksi = ?, id_lokasi = ?, id_jenis_tanaman = ?, tahun = ? WHERE id = ?";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, luasPanen);
            perintah.setString(2, produksi);
            perintah.setString(3, idLokasi);
            perintah.setString(4, idJenisTanaman);
            perintah.setString(5, tahun);
            perintah.setString(6, id);
            perintah.executeUpdate();
            System.out.println("Data berhasil diubah");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void hapustanaman(String id) {
        try {
            String kode = "DELETE FROM data_tanaman WHERE id = ?";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, id);
            perintah.executeUpdate();
            System.out.println("Data berhasil dihapus");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    
    public void simpanjTanaman(String varid, String varnama) {
        try {
            String kode = "insert into jenis_tanaman (id_jenis_tanaman, nama_tanaman) value(?,?)";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, varid);
            perintah.setString(2, varnama);
            perintah.executeUpdate();
            System.out.println("Data berhasil disimpan");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void ubahjTanaman(String varid, String varnama) {
        try {
            String kode = "update jenis_tanaman set nama_tanaman=? where id_jenis_tanaman=?";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, varnama);
            perintah.setString(2, varid);
            perintah.executeUpdate();
            System.out.println("Data berhasil diubah");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void hapusjTanaman(String varid) {
        try {
            String kode = "delete from jenis_tanaman where id_jenis_tanaman=?";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, varid);
            perintah.executeUpdate();
            System.out.println("Data berhasil dihapus");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    
    public void simpanLokasi(String id_lokasi, String kecamatan, String kabkot, String provinsi) {
        try {
            String kode = "insert into lokasi (id_lokasi, kecamatan, kabkot, provinsi) values (?, ?, ?, ?)";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, id_lokasi);
            perintah.setString(2, kecamatan);
            perintah.setString(3, kabkot);
            perintah.setString(4, provinsi);
            perintah.executeUpdate();
            System.out.println("Data berhasil disimpan");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void ubahLokasi( String id_lokasi, String kecamatan, String kabkot, String provinsi) {
        try {
            String kode = "update lokasi set kecamatan=?, kabkot=?, provinsi=? where id_lokasi=?";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, kecamatan);
            perintah.setString(2, kabkot);
            perintah.setString(3, provinsi);
            perintah.setString(4, id_lokasi);
            perintah.executeUpdate();
            System.out.println("Data berhasil diubah");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    public void hapusLokasi(String id_lokasi) {
        try {
            String kode = "delete from lokasi where id_lokasi=?";
            PreparedStatement perintah = koneksidb.prepareStatement(kode);
            perintah.setString(1, id_lokasi);
            perintah.executeUpdate();
            System.out.println("Data berhasil dihapus");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
