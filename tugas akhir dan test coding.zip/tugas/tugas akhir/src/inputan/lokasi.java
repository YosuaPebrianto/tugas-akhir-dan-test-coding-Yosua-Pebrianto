/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inputan;

import java.sql.PreparedStatement;
import java.sql.Connection;

/**
 *
 * @author User
 */
public class lokasi {
    String id_lokasi, kecamatan, kabkot, provinsi;
    
    public lokasi() {}

    public lokasi(String id_lokasi, String kecamatan, String kabkot, String provinsi) {
        this.id_lokasi = id_lokasi;
        this.kecamatan = kecamatan;
        this.kabkot = kabkot;
        this.provinsi = provinsi;
    }

    public void inputID_LOKASI(String id_lokasi) {
        this.id_lokasi = id_lokasi;
    }

    public String ambilID_LOKASI() {
        return this.id_lokasi;
    }

    public void inputKECAMATAN(String kecamatan) {
        this.kecamatan = kecamatan;
    }

    public String ambilKECAMATAN() {
        return this.kecamatan;
    }

    public void inputKABKOT(String kabkot) {
        this.kabkot = kabkot;
    }

    public String ambilKABKOT() {
        return this.kabkot;
    }

    public void inputPROVINSI(String provinsi) {
        this.provinsi = provinsi;
    }

    public String ambilPROVINSI() {
        return this.provinsi;
    }
}