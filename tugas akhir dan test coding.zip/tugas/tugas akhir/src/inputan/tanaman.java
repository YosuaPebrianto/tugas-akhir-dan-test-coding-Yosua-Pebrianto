/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inputan;

/**
 *
 * @author User
 */
public class tanaman {
    String id, luasPanen, produksi, idLokasi, idJenisTanaman, tahun;

    public tanaman() {}

    public tanaman(String id, String luasPanen, String produksi, String idLokasi, String idJenisTanaman, String tahun) {
        this.id = id;
        this.luasPanen = luasPanen;
        this.produksi = produksi;
        this.idLokasi = idLokasi;
        this.idJenisTanaman = idJenisTanaman;
        this.tahun = tahun;
    }

    public void inputID(String id) {
        this.id = id;
    }

    public String ambilID() {
        return this.id;
    }

    public void inputLuasPanen(String luasPanen) {
        this.luasPanen = luasPanen;
    }

    public String ambilLuasPanen() {
        return this.luasPanen;
    }

    public void inputProduksi(String produksi) {
        this.produksi = produksi;
    }

    public String ambilProduksi() {
        return this.produksi;
    }

    public void inputIDLokasi(String idLokasi) {
        this.idLokasi = idLokasi;
    }

    public String ambilIDLokasi() {
        return this.idLokasi;
    }

    public void inputIDJenisTanaman(String idJenisTanaman) {
        this.idJenisTanaman = idJenisTanaman;
    }

    public String ambilIDJenisTanaman() {
        return this.idJenisTanaman;
    }

    public void inputTahun(String tahun) {
        this.tahun = tahun;
    }

    public String ambilTahun() {
        return this.tahun;
    }
}
