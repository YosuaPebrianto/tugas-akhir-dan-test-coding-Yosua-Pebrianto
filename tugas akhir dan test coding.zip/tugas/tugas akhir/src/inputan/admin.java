/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inputan;

/**
 *
 * @author User
 */
public class admin {
String id_admin, username, password, nama_lengkap;
    
    public admin (){}
    
    public admin(String id_admin, String username, String password, String nama_lengkap){
        this.id_admin = id_admin;
        this.username = username;
        this.password = password;
        this.nama_lengkap = nama_lengkap;
        
    }
    
    public void inputID_ADMIN(String id_admin){
        this.id_admin = id_admin;
    }
    
    public String ambilID_ADMIN(){
        return this.id_admin;
    }
    
    public void inputUSERNAME(String username){
        this.username = username;
    }
    
    public String ambilUSERNAME(){
        return this.username;
    }
    
    public void inputPASSWORD(String password){
        this.password = password;
    }
    
    public String ambilPASSWORD(){
        return this.password;
    }
    
    public void inputNAMA_LENGKAP(String nama_lengkap){
        this.nama_lengkap = nama_lengkap;
    }
    
    public String ambilNAMA_LENGKAP(){
        return this.nama_lengkap;
    }    
}
