/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inputan;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author User
 */
public class jenis_tanaman {
    String id_jenis_tanaman, nama_tanaman;

    public jenis_tanaman() {}

    public jenis_tanaman(String id_jenis_tanaman, String nama_tanaman) {
        this.id_jenis_tanaman = id_jenis_tanaman;
        this.nama_tanaman = nama_tanaman;
    }

    public void inputID_JENIS_TANAMAN(String id_jenis_tanaman) {
        this.id_jenis_tanaman = id_jenis_tanaman;
    }

    public String ambilID_JENIS_TANAMAN() {
        return this.id_jenis_tanaman;
    }

    public void inputNAMA_TANAMAN(String nama_tanaman) {
        this.nama_tanaman = nama_tanaman;
    }

    public String ambilNAMA_TANAMAN() {
        return this.nama_tanaman;
    }
}