/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugaspertanian;
import inputan.*;
import java.util.Scanner;
import crud.koneksi;
import gui.frameUtama;
/**
 *
 * @author User
 */
public class Tugaspertanian {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        koneksi db=new koneksi();
        //db.ubahadmin("2210202", "admin", "132", "WAWA");
        //db.hapusadmin("2210202");
    new frameUtama().setVisible(true);
    
}
}
