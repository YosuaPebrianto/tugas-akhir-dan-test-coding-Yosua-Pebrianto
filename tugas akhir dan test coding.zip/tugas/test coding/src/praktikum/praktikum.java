/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum;

/**
 *
 * @author User
 */
public class praktikum {
    
    String kode, buku, kondisi;
    int  nilkondisi, ambilkondisi ;
    
    public praktikum(){}
    
    public void praktikum (String kode, String buku, String kondisi){
        this.kode = kode;
        this.buku = buku;
        this.kondisi = kondisi;
    }
    
    public void inputkode(String kode){
        this.kode = kode;
    }
    
    public String ambilkode(){
        return this.kode;
    }
    
    public void inputbuku(String buku){
        this.buku = buku;
    }
    
    public String ambilbuku(){
        return this.buku;
    }
    
    public int ambilkondisi(){
        this.nilkondisi =0;
        if (this.kondisi.equals("BAIK")){
            this.nilkondisi = 50000;
        }else{ 
            this.nilkondisi = 15000;}
        return this.nilkondisi;
        }
    
    public int hasilnominal(){
        return ambilkondisi();
    }
    
 }

