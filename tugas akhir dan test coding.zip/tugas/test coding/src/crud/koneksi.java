/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;
import praktikum.*;
import ujian.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author User
 */
public class koneksi {
private String databasename="ujian";
    private String username="root";
    private String password="";
    private String lokasi="jdbc:mysql://localhost/"+databasename;
    public static Connection koneksidb;
    
    public koneksi(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            koneksidb=DriverManager.getConnection(lokasi,username,password);
            System.out.println("Databse Terkoneksi");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }    
    
    private int nominal(String kondisi) throws IllegalAccessException{
        if (kondisi.equalsIgnoreCase("BAIK")){
            return 50000;
        } else if (kondisi.equalsIgnoreCase("RUSAK")){
            return 15000;
        } else {
            throw new IllegalAccessException("kondisi tidak valid");
        }
    }
    
    public void simpanujian(String varkode, String varbuku, String varkondisi){
        try {
            int nominal = nominal(varkondisi);
            
            String kode="insert into praktikum (kode,buku,kondisi,nominal) value(?,?,?,?)";
            PreparedStatement perintah=koneksidb.prepareStatement(kode);
            perintah.setString(1, varkode);
            perintah.setString(2, varbuku);
            perintah.setString(3, varkondisi);
            perintah.setInt(4, nominal);
            perintah.executeUpdate();
            System.out.println("data berhasil disimpan");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    
    public void ubahujian(String varbuku, String varkondisi, String varkode) {
    try {
        int nominal = nominal(varkondisi);

        String kode = "update praktikum set buku=?, kondisi=?, nominal=? where kode=?";
        PreparedStatement perintah = koneksidb.prepareStatement(kode);
        perintah.setString(1, varbuku);
        perintah.setString(2, varkondisi);
        perintah.setInt(3, nominal);
        perintah.setString(4, varkode);
        perintah.executeUpdate();
        System.out.println("data berhasil diubah");
    } catch (Exception e) {
        System.err.println(e.getMessage());
    }
}

public void hapusujian(String varkode) {
    try {
        String kode = "delete from praktikum where kode=?";
        PreparedStatement perintah = koneksidb.prepareStatement(kode);
        perintah.setString(1, varkode);
        perintah.executeUpdate();
        System.out.println("data berhasil dihapus");
    } catch (Exception e) {
        System.err.println(e.getMessage());
    }
}
            
}
    
    
